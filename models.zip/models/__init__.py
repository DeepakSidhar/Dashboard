from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from .user import User # importing the user table
from .change_management import Change_Management # importing the Change_Management table
from .hardware import Hardware # importing the Hardware table
from .incident_management import Incident_Management # importing the User_Role table
from .permission import Permission # importing the User_Role table
from .problem_managment import Problem_Management # importing the User_Role table
from .role import Role # importing the User_Role table
from .role_permission import User_Role # importing the User_Role table
from .software import Software # importing the software table
from .user_role  import User_Role # importing the User_Role table