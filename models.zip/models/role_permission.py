from . import db
import datetime

class Role_Permission(db.Model): # user class is a subclass of  db.Model
    __tablename__ = 'role_permission'  # optional this is to id the table
    user_id = db.Column(db.Integer, primary_key=True), db.ForeignKey("user.id")
    permission_id = db.Column(db.Integer, primary_key=True), db.ForeignKey("permission.id") # needs to e a forgnn key TODO
    created_at = db.Column(db.DateTime, default=datetime.datetime.now(datetime.timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.now(datetime.timezone.utc), nullable=False)

